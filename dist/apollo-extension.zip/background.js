function contactCheckerBackgroundLog(event, details = {}) {
  const timestamp = new Date().toISOString();
  console.log(`[ContactChecker BG] ${timestamp} ${event}`, details);
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;

  contactCheckerBackgroundLog("EXTENSION_TOGGLE_CLICKED", {
    tabId: tab.id,
    url: tab.url || ""
  });

  try {
    chrome.tabs.sendMessage(tab.id, { type: "TOGGLE_CONTACT_CHECKER" }, async (response) => {
      if (chrome.runtime.lastError || !response?.success) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content.js"]
          });
          contactCheckerBackgroundLog("CONTENT_SCRIPT_INJECTED", { tabId: tab.id });
        } catch (err) {
          console.error("Could not inject Contact Checker:", err);
        }
      }
    });
  } catch (error) {
    console.error("Could not activate Contact Checker:", error);
  }
});

async function callBackendApi(endpoint, body) {
  const stored = await chrome.storage.local.get(["contactCheckerBackendUrl", "contactCheckerApiToken"]);
  const configuredHost = String(stored.contactCheckerBackendUrl || "").trim().replace(/\/+$/, "");
  const hosts = configuredHost
    ? [configuredHost]
    : ["http://127.0.0.1:8000", "http://localhost:8000"];
  const apiToken = String(stored.contactCheckerApiToken || "").trim();
  let lastError = null;

  for (const host of hosts) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout
    try {
      const response = await fetch(`${host}${endpoint}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(apiToken ? { "X-Contact-Checker-Token": apiToken } : {})
        },
        body: JSON.stringify(body),
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`API error: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (err) {
      clearTimeout(timeoutId);
      lastError = err;
    }
  }

  throw lastError || new Error("Unable to connect to Contact Checker Backend on port 8000.");
}

async function fetchAccountRenewals() {
  const stored = await chrome.storage.local.get(["contactCheckerBackendUrl", "contactCheckerApiToken"]);
  const configuredHost = String(stored.contactCheckerBackendUrl || "").trim().replace(/\/+$/, "");
  const hosts = configuredHost
    ? [configuredHost]
    : ["http://127.0.0.1:8000", "http://localhost:8000"];
  const apiToken = String(stored.contactCheckerApiToken || "").trim();
  let lastError = null;
  for (const host of hosts) {
    try {
      const response = await fetch(`${host}/api/v1/account-renewals`, {
        headers: apiToken ? { "X-Contact-Checker-Token": apiToken } : {}
      });
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      return await response.json();
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || new Error("Unable to reach backend on port 8000.");
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  let endpoint;
  let body;

  if (message.type === "GET_ACCOUNT_RENEWALS") {
    fetchAccountRenewals()
      .then((data) => sendResponse({ success: data.status === "ok", renewals: data.renewals || {} }))
      .catch((error) => sendResponse({ success: false, error: error?.message || String(error) }));
    return true;
  }

  if (message.type === "CHECK_EMAILS") {
    endpoint = "/check";
    body = { emails: message.emails };
  } else if (message.type === "MATCH_APOLLO") {
    endpoint = "/match-apollo";
    body = {
      contacts: message.contacts,
      batch: message.batch || "batch_1",
      title_guardrail_enabled: message.title_guardrail_enabled !== false,
      indian_name_guardrail_enabled: message.indian_name_guardrail_enabled !== false,
      page_number: message.page_number || null,
      max_contacts_per_company: message.max_contacts_per_company || 1
    };
  } else if (message.type === "SYNC_SAVED_LEADS") {
    endpoint = "/sync-saved-leads";
    body = {
      batch: message.batch || "batch_1",
      contacts: message.contacts || [],
      replace_all: Boolean(message.replace_all),
      cycle: message.cycle || "",
      account_used: message.account_used || "",
      page_number: message.page_number || null,
      max_contacts_per_company: message.max_contacts_per_company || 1
    };
  } else if (message.type === "EVALUATE_PENDING_TITLES" || message.type === "EVALUATE_PENDING_BATCH") {
    endpoint = "/evaluate-pending-titles";
    body = {
      batch: message.batch || "batch_1",
      titles: message.titles || [],
      names: message.names || []
    };
  } else if (message.type === "LOG_EXTENSION_ACTIVITY") {
    endpoint = "/log-extension-activity";
    body = message.entry || {};
  } else if (message.type === "FLUSH_QUEUES") {
    endpoint = "/flush-pending-queues";
    body = {};
  } else {
    // Unrecognized message
    return false;
  }

  const startedAt = performance.now();

  contactCheckerBackgroundLog("API_REQUEST_STARTED", {
    endpoint,
    contactCount: Array.isArray(body.contacts) ? body.contacts.length : undefined,
    emailCount: Array.isArray(body.emails) ? body.emails.length : undefined
  });

  callBackendApi(endpoint, body)
    .then((data) => {
      const durationMs = Math.round(performance.now() - startedAt);
      contactCheckerBackgroundLog("API_REQUEST_COMPLETE", {
        endpoint,
        durationMs,
        summary: data.summary || null
      });

      sendResponse({
        success: true,
        ...data,
        results: data.results,
        activity: data.activity || [],
        summary: data.summary || {}
      });
    })
    .catch((error) => {
      const durationMs = Math.round(performance.now() - startedAt);
      console.error("Contact Checker API error:", error);
      contactCheckerBackgroundLog("API_REQUEST_ERROR", {
        endpoint,
        durationMs,
        error: error?.message || String(error)
      });

      sendResponse({
        success: false,
        error: error?.message || String(error)
      });
    });

  return true; // Keep message port open for async response
});

// Keep-alive heartbeat to prevent Service Worker sleep drops
chrome.alarms.create("keepAlive", { periodInMinutes: 0.33 }); // ~20 seconds
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "keepAlive") {
    // Keep alive active
  }
});
